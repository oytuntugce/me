# Me

**Description**:  This is a repository aiming to help complete beginners who want to learn how to code, take their first step.


  - **Technology stack**: For the first part of the project it will only consist of HTML but I will add more stuff into it.
  - **Status**:  Alpha